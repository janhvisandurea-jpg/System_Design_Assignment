#ifndef SHOW_H
#define SHOW_H
#include <iostream>
using namespace std;

class Show {
    string time;
public:
    Show(string t);
    void showTime();
};
#endif
