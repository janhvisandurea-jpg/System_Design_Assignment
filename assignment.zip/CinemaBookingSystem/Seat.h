#ifndef SEAT_H
#define SEAT_H
#include <iostream>
using namespace std;

class Seat {
    int seatNo;
    bool booked;
public:
    Seat(int n);
    void bookSeat();
};
#endif
