#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <iostream>
using namespace std;

class Customer {
    string name;
public:
    Customer(string n);
    void showCustomer();
};
#endif
