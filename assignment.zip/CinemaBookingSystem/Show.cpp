#include "Show.h"

Show::Show(string t) { time = t; }
void Show::showTime() { cout << "Show: " << time << endl; }
