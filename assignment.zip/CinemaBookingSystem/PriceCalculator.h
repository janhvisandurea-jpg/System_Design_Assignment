#ifndef PRICECALCULATOR_H
#define PRICECALCULATOR_H
#include <iostream>
using namespace std;

class PriceCalculator {
public:
    int calculatePrice(int seatCount);
};
#endif
