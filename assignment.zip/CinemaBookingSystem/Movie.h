#ifndef MOVIE_H
#define MOVIE_H
#include <iostream>
using namespace std;

class Movie {
    string title;
public:
    Movie(string t);
    void showMovie();
};
#endif
