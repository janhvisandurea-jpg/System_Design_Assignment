#ifndef TICKETPRINTER_H
#define TICKETPRINTER_H
#include <iostream>
using namespace std;

class TicketPrinter {
public:
    void printTicket();
};
#endif
