#include "Customer.h"

Customer::Customer(string n) { name = n; }
void Customer::showCustomer() { cout << "Customer: " << name << endl; }
