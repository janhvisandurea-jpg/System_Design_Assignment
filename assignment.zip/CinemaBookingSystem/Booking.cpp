#include "Booking.h"

void Booking::confirmBooking() { cout << "Booking confirmed.\n"; }
