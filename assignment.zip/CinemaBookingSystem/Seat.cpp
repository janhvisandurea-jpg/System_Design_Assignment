#include "Seat.h"

Seat::Seat(int n) { seatNo = n; booked = false; }
void Seat::bookSeat() { booked = true; cout << "Seat " << seatNo << " booked.\n"; }
