#include "Movie.h"

Movie::Movie(string t) { title = t; }
void Movie::showMovie() { cout << "Movie: " << title << endl; }
