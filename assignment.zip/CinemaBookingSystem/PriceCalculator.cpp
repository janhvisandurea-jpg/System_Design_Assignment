#include "PriceCalculator.h"

int PriceCalculator::calculatePrice(int seatCount) {
    return seatCount * 250; // fixed price per seat
}
