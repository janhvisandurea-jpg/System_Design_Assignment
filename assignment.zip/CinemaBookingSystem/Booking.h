#ifndef BOOKING_H
#define BOOKING_H
#include <iostream>
using namespace std;

class Booking {
public:
    void confirmBooking();
};
#endif
