#include "Payment.h"

void Payment::makePayment(string mode) {
    cout << "Payment done via " << mode << endl;
}
