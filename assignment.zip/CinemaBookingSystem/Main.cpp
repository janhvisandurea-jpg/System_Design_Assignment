#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Seat {
    string code;
    bool booked;
    int price;
    Seat(string c, int p) : code(c), booked(false), price(p) {}
};

int main() {
    cout << "===== MOVIE TICKET BOOKING =====\n";
    cout << "1. Movies  2. Book  0. Exit\n";
    cout << "Choose: ";
    int choice; cin >> choice;

    if(choice == 1) {
        cout << "\n[1] 3 Idiots   Hindi   170 min\n";
        cout << "[2] Interstellar   English   169 min\n";
        cout << "Choose movie: ";
        int m; cin >> m;

        string movie = (m==1) ? "3 Idiots" : "Interstellar";

        cout << "\n[1] Screen-1   06:00 PM\n";
        cout << "[2] Screen-2   09:00 PM\n";
        cout << "Choose show: ";
        int s; cin >> s;

        string show = (s==1) ? "Screen-1 06:00 PM" : "Screen-2 09:00 PM";

        // Seats
        vector<Seat> seats = {
            Seat("A1",150), Seat("A2",150), Seat("B1",250), Seat("B2",250), Seat("C1",300)
        };

        cout << "\nAvailable Seats:\n";
        for(auto &seat : seats) {
            cout << seat.code << " [" << (seat.booked ? "X" : " ") << "] Rs." << seat.price << "\n";
        }

        cout << "Enter seat codes (e.g. A1,B2): ";
        string s1,s2; cin >> s1 >> s2;

        int total=0;
        for(auto &seat : seats) {
            if(seat.code==s1 || seat.code==s2) {
                seat.booked=true;
                total += seat.price;
            }
        }

        cout << "\nTOTAL Rs." << total << endl;
        cout << "Pay by: 1.UPI  2.Card  3.Cash > ";
        int pay; cin >> pay;
        string mode = (pay==1)?"UPI":(pay==2)?"Card":"Cash";

        cout << "\n=============== TICKET ===============\n";
        cout << "Movie      : " << movie << endl;
        cout << "Show       : " << show << endl;
        cout << "Seats      : " << s1 << ", " << s2 << endl;
        cout << "Amount     : Rs." << total << "   Status: CONFIRMED\n";
        cout << "Payment    : " << mode << " successful\n";
        cout << "======================================\n";
    }

    return 0;
}
