#include "TicketPrinter.h"

void TicketPrinter::printTicket() {
    cout << "Ticket printed successfully!\n";
}
